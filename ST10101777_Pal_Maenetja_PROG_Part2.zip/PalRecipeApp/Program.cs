﻿using System;
using System.Collections.Generic;

//  create recipe and ingridient classes
public class Recipe
{
    public string Name { get; set; }
    public List<Ingredient> Ingredients

    { get; set; }


    public delegate void
   RecipeCaloriesExceededHandler(Recipe
    recipe);
    public event
    RecipeCaloriesExceededHandler
     CaloriesExceeded;

    public Recipe(string name)
    {
        Name = name;
        Ingredients = new
         List<Ingredient>();
    }
    public void AddIngredient(Ingredient
     ingredient)
    {

        Ingredients.Add(ingredient);
    }
    public int CalculateTotalCalories()
    {
        int totalCalories = 0;
        foreach (var ingredient in
         Ingredients)
        {

            totalCalories +=
             ingredient.Calories;
        }
        return totalCalories;
    }
}
public class Ingredient

{

    public string Name { get; set; }
    public int Calories { get; set; }
    public string FoodGroup { get; set; }

        public Ingredient(string name, int  calories, string foodGroup)
        {
            Name = name;
            Calories = calories;
            FoodGroup = foodGroup;

        }
    }

public class Program
{
    //  Implementation of the Generic Collections
    private static List<Recipe> recipes = new List<Recipe>();

    static void Main()
    {
        //  Implementation of the  User Interface Changes

        while (true)
        {
            Console.WriteLine("1. AddRecipe");
            Console.WriteLine("2.Display Recipes");
            Console.WriteLine("3. Select1.Recipe");
            Console.WriteLine("4.2.Exit");
            Console.WriteLine("Put your choice: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1": AddRecipe(); break;
                case "2": DisplayRecipes(); break;
                case "3": SelectRecipe(); break;
                case "4": return;
                default:
                    Console.WriteLine("Incorrect choice,Please try again.");
                    break;
            }
        }
    }
    private static void AddRecipe()
    {
        Console.WriteLine("Enter recipe name: ");
        string name = Console.ReadLine();

        Recipe recipe = new Recipe(name);

        //  classifying  Recipes by Name
        recipes.Add(recipe);
        recipes.Sort((r1, r2) => r1.Name.CompareTo(r2.Name));
        Console.WriteLine("Enter ingredient details(or type 'done' to execute):");

        while (true)
        {
            Console.WriteLine("Ingredient Name:");
            string ingredientName = Console.ReadLine();
            if (ingredientName.ToLower() == "done")

                break;
            Console.WriteLine("Calories:");
            int calories = int.Parse(Console.ReadLine());

            Console.WriteLine("Food Group:");
            string foodGroup = Console.ReadLine();
            Ingredient ingredient = new Ingredient(ingredientName, calories, foodGroup);
            recipe.AddIngredient(ingredient);
        }
    }
    private static void DisplayRecipes()
    {
        Console.WriteLine("Recipes:");
        foreach (var recipe in recipes)
        {
            Console.WriteLine(recipe.Name);

        }
    }
    private static void SelectRecipe()
    {
        Console.WriteLine("Enter recipe name:");
        string recipeName = Console.ReadLine();
        Recipe selectedRecipe = recipes.Find(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));

        if (selectedRecipe != null)

        {
            //  The calculation of Total of the Calories
            int totalCalories = selectedRecipe.CalculateTotalCalories();
            Console.WriteLine("Total Calories: " + totalCalories);

            // tell the User for high Calories

            if (totalCalories > 300)
            {
                Console.WriteLine("Warning: Calories  exceed 300!");


                selectedRecipe.CaloriesExceeded.Invoke(selectedRecipe);
            }

            else
            {
                Console.WriteLine("Recipe not found.");
            }
        }
    }
}

